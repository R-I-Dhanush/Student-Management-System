package com.example.sms;
public class SmsApplication { public static void main(String[] args) {} }