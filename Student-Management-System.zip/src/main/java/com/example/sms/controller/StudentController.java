package com.example.sms.controller;
public class StudentController {}