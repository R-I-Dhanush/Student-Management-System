package com.example.sms.repository;
public interface StudentRepository {}